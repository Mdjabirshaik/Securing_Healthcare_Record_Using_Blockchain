import React from'react'; 
import Body from "./components/Javascript/Body";
function App() {
  return (
    <div>
     <Body/> 
    </div>
  );
}

export default App;
